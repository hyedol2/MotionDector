@echo off
echo ============================================
echo  MotionController - Build Script
echo ============================================

pip install -r requirements.txt

echo.
echo Building EXE...
pyinstaller build.spec --clean --noconfirm

echo.
if exist "dist\MotionController\MotionController.exe" (
    echo [SUCCESS] Build complete!
    echo Output: dist\MotionController\MotionController.exe
) else (
    echo [FAILED] Build failed. Check the output above.
)
pause
