"""
gesture_engine.py
동작 인식 상태 머신 - 히스테리시스 + 시간 기반 로직
"""
import time
import logging
from enum import Enum, auto
from typing import Optional, Dict, Set
from collections import deque
import numpy as np

from pose_tracker import PoseTracker

logger = logging.getLogger("GestureEngine")


class Action(Enum):
    NONE = auto()
    RUN = auto()
    BACK = auto()
    LEFT = auto()
    RIGHT = auto()
    JUMP = auto()
    PUNCH = auto()


class GestureEngine:
    """
    포즈 데이터를 입력받아 Action을 출력하는 상태 머신
    - 히스테리시스: 진입/유지/종료 임계값 분리
    - 시간 기반: 최소 지속 시간, 쿨다운 적용
    - 오작동 방지: 점프 중 다른 동작 억제 등
    """

    def __init__(self, config: dict):
        self.cfg = config
        self.sens = config["sensitivity"]

        # 현재 활성 동작 집합
        self.active_actions: Set[Action] = set()

        # 타이머 및 상태
        self._run_active = False
        self._run_start_time: Optional[float] = None
        self._run_last_trigger = 0.0

        self._back_active = False
        self._back_start_time: Optional[float] = None
        self._back_last_trigger = 0.0

        self._left_active = False
        self._left_start_time: Optional[float] = None
        self._left_last_trigger = 0.0

        self._right_active = False
        self._right_start_time: Optional[float] = None
        self._right_last_trigger = 0.0

        self._jump_cooldown_until = 0.0
        self._is_jumping = False
        self._jump_triggered = False
        self._prev_center_y: Optional[float] = None

        self._punch_cooldown_until = 0.0
        self._punch_triggered_this_cycle_left = False
        self._punch_triggered_this_cycle_right = False
        self._prev_left_wrist_speed = 0.0
        self._prev_right_wrist_speed = 0.0

        # 달리기 감지용: 무릎 Y 히스토리
        self._left_knee_y_hist: deque = deque(maxlen=20)
        self._right_knee_y_hist: deque = deque(maxlen=20)
        self._knee_peak_times: deque = deque(maxlen=10)

        # 중심 Y 히스토리 (점프 감지)
        self._center_y_hist: deque = deque(maxlen=15)

        # 전방 진출 히스토리 (달리기 vs 뒤로가기)
        self._center_z_hist: deque = deque(maxlen=15)

        self._last_update = time.time()

        # 단발성 동작 큐
        self._event_queue: deque = deque()

    def update(self, tracker: PoseTracker) -> Set[Action]:
        """
        PoseTracker 상태로 현재 활성 동작 집합을 계산하고 반환
        - 지속형: RUN, BACK, LEFT, RIGHT (키 홀드)
        - 단발형: JUMP, PUNCH (1회성 이벤트, 큐로 관리)
        """
        now = time.time()
        self.active_actions.clear()

        center = tracker.get_center()
        center_vel = tracker.get_center_velocity()

        if center is not None:
            self._center_y_hist.append(center[1])
        if center_vel is not None:
            self._center_z_hist.append(center_vel[2] if len(center_vel) > 2 else 0.0)

        # 점프 감지 (최우선 - 점프 중에는 이동 억제)
        jump_detected = self._detect_jump(tracker, now)
        if jump_detected:
            self._event_queue.append(Action.JUMP)

        # 달리기 / 후진 / 좌우 감지
        if not self._is_jumping:
            run_detected = self._detect_run(tracker, now)
            back_detected = self._detect_back(tracker, now)
            left_detected = self._detect_strafe_left(tracker, now)
            right_detected = self._detect_strafe_right(tracker, now)

            if run_detected:
                self.active_actions.add(Action.RUN)
            if back_detected and not run_detected:
                self.active_actions.add(Action.BACK)
            if left_detected and not run_detected and not back_detected:
                self.active_actions.add(Action.LEFT)
            if right_detected and not run_detected and not back_detected:
                self.active_actions.add(Action.RIGHT)

        # 펀치 감지 (점프 중이 아닐 때만)
        if not self._is_jumping:
            punch_count = self._detect_punch(tracker, now)
            for _ in range(punch_count):
                self._event_queue.append(Action.PUNCH)

        # 단발 이벤트를 active_actions에 포함 (이번 프레임에 처리될 것들)
        while self._event_queue:
            self.active_actions.add(self._event_queue.popleft())

        if not self.active_actions:
            self.active_actions.add(Action.NONE)

        self._last_update = now
        return self.active_actions.copy()

    # ─────────────────────────────────────────────
    # 달리기 감지
    # ─────────────────────────────────────────────
    def _detect_run(self, tracker: PoseTracker, now: float) -> bool:
        """
        무릎의 수직 진동 빈도로 달리기 감지
        - 제자리 뛰기: 무릎이 빠르게 올라갔다 내려옴
        - 달리기: 무릎 속도가 임계값 이상
        """
        lk = tracker.joints["left_knee"]
        rk = tracker.joints["right_knee"]

        lk_speed_y = lk.recent_max_speed_y(6)
        rk_speed_y = rk.recent_max_speed_y(6)
        max_knee_speed = max(lk_speed_y, rk_speed_y)

        thresh = self.sens["run_knee_velocity_threshold"]
        stop_timeout = self.sens["run_stop_timeout"]
        min_dur = self.sens["run_min_duration"]

        triggered = max_knee_speed > thresh

        if triggered:
            self._run_last_trigger = now
            if self._run_start_time is None:
                self._run_start_time = now
        else:
            if now - self._run_last_trigger > stop_timeout:
                self._run_active = False
                self._run_start_time = None

        if (self._run_start_time is not None and
                now - self._run_start_time >= min_dur):
            self._run_active = True

        return self._run_active

    # ─────────────────────────────────────────────
    # 후진 감지
    # ─────────────────────────────────────────────
    def _detect_back(self, tracker: PoseTracker, now: float) -> bool:
        """
        힙 중심의 Z축 속도 (뒤로 멀어지는 방향) 또는
        무릎 속도가 낮은 상태에서 힙이 후방으로 이동
        """
        center_vel = tracker.get_center_velocity()
        if center_vel is None:
            return False

        # Z 양수 = 카메라에서 멀어짐 = 뒤로
        z_vel = float(center_vel[2]) if len(center_vel) > 2 else 0.0
        thresh = self.sens["strafe_hip_velocity_threshold"]
        stop_timeout = self.sens["strafe_stop_timeout"]
        min_dur = self.sens["strafe_min_duration"]

        # 무릎 속도 낮아야 뒤로가기 (달리기랑 구분)
        lk_speed = tracker.joints["left_knee"].speed()
        rk_speed = tracker.joints["right_knee"].speed()
        knee_moving = max(lk_speed, rk_speed) > self.sens["run_knee_velocity_threshold"] * 0.7

        triggered = z_vel > thresh and not knee_moving

        if triggered:
            self._back_last_trigger = now
            if self._back_start_time is None:
                self._back_start_time = now
        else:
            if now - self._back_last_trigger > stop_timeout:
                self._back_active = False
                self._back_start_time = None

        if (self._back_start_time is not None and
                now - self._back_start_time >= min_dur):
            self._back_active = True

        return self._back_active

    # ─────────────────────────────────────────────
    # 좌우 이동 감지
    # ─────────────────────────────────────────────
    def _detect_strafe_left(self, tracker: PoseTracker, now: float) -> bool:
        """
        화면 기준 오른쪽으로 이동 = A키 (카메라 좌표계 반전)
        힙 중심 X 속도가 양수 (오른쪽으로)
        """
        center_vel = tracker.get_center_velocity()
        if center_vel is None:
            return False

        x_vel = float(center_vel[0])
        thresh = self.sens["strafe_hip_velocity_threshold"]
        stop_timeout = self.sens["strafe_stop_timeout"]
        min_dur = self.sens["strafe_min_duration"]

        triggered = x_vel > thresh  # 화면 오른쪽 = x 증가

        if triggered:
            self._left_last_trigger = now
            if self._left_start_time is None:
                self._left_start_time = now
        else:
            if now - self._left_last_trigger > stop_timeout:
                self._left_active = False
                self._left_start_time = None

        if (self._left_start_time is not None and
                now - self._left_start_time >= min_dur):
            self._left_active = True

        return self._left_active

    def _detect_strafe_right(self, tracker: PoseTracker, now: float) -> bool:
        """화면 기준 왼쪽으로 이동 = D키"""
        center_vel = tracker.get_center_velocity()
        if center_vel is None:
            return False

        x_vel = float(center_vel[0])
        thresh = self.sens["strafe_hip_velocity_threshold"]
        stop_timeout = self.sens["strafe_stop_timeout"]
        min_dur = self.sens["strafe_min_duration"]

        triggered = x_vel < -thresh

        if triggered:
            self._right_last_trigger = now
            if self._right_start_time is None:
                self._right_start_time = now
        else:
            if now - self._right_last_trigger > stop_timeout:
                self._right_active = False
                self._right_start_time = None

        if (self._right_start_time is not None and
                now - self._right_start_time >= min_dur):
            self._right_active = True

        return self._right_active

    # ─────────────────────────────────────────────
    # 점프 감지
    # ─────────────────────────────────────────────
    def _detect_jump(self, tracker: PoseTracker, now: float) -> bool:
        """
        신체 중심이 빠르게 위로 상승 → 점프
        - Y 좌표 감소 = 위로 올라감 (이미지 좌표계)
        - 최소 상승 거리 + 속도 임계값
        """
        if now < self._jump_cooldown_until:
            return False

        center = tracker.get_center()
        center_vel = tracker.get_center_velocity()
        if center is None or center_vel is None:
            return False

        # Y 속도 음수 = 위로
        vy = float(center_vel[1])
        thresh = self.sens["jump_velocity_threshold"]
        min_rise = self.sens["jump_min_rise"]

        # 최근 히스토리에서 Y 변화량 확인
        if len(self._center_y_hist) >= 5:
            recent_y = list(self._center_y_hist)
            y_change = recent_y[-5] - recent_y[-1]  # 양수 = 올라감
        else:
            y_change = 0.0

        is_rising = vy < -thresh and y_change > min_rise

        if is_rising and not self._is_jumping:
            self._is_jumping = True
            self._jump_cooldown_until = now + self.sens["jump_cooldown"]
            logger.debug(f"JUMP detected: vy={vy:.4f}, y_change={y_change:.4f}")
            return True

        # 착지 감지
        if self._is_jumping:
            if vy > -thresh * 0.3:
                self._is_jumping = False

        return False

    # ─────────────────────────────────────────────
    # 펀치 감지
    # ─────────────────────────────────────────────
    def _detect_punch(self, tracker: PoseTracker, now: float) -> int:
        """
        손목의 급격한 가속 + 전방 이동 궤적
        - 속도 피크 + 가속도 임계값
        - 쿨다운으로 연속 펀치 지원
        반환: 이번 프레임에 감지된 펀치 수 (0 or 1)
        """
        lw = tracker.joints["left_wrist"]
        rw = tracker.joints["right_wrist"]

        count = 0
        punch_vel_thresh = self.sens["punch_wrist_velocity_threshold"]
        punch_acc_thresh = self.sens["punch_acceleration_threshold"]
        punch_ext = self.sens["punch_extension_threshold"]
        cooldown = self.sens["punch_cooldown"]

        for wrist, side in [(lw, "left"), (rw, "right")]:
            if now < self._punch_cooldown_until:
                break

            if wrist.vel is None or wrist.acc is None:
                continue

            spd = wrist.speed()
            acc = wrist.accel_magnitude()

            # 손목 Z 방향 속도 (앞으로 뻗음 = z 감소)
            z_vel = float(wrist.vel[2]) if wrist.vel is not None else 0.0

            # 속도 피크 + 가속도 + 전방 이동 조합
            is_punch = (spd > punch_vel_thresh and
                        acc > punch_acc_thresh and
                        z_vel < -punch_ext)

            if is_punch:
                logger.debug(f"PUNCH {side}: spd={spd:.4f}, acc={acc:.4f}, z_vel={z_vel:.4f}")
                self._punch_cooldown_until = now + cooldown
                count += 1
                break  # 한 프레임에 최대 1개

        return count
