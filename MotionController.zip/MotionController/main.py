"""
main.py
MotionController - 웹캠 기반 게임 동작 인식기
실행: python main.py
빌드: pyinstaller build.spec
"""
import sys
import os
import cv2
import time
import json
import logging
import threading
import numpy as np
from collections import deque
from typing import Set

# 경로 설정 (PyInstaller 대응)
if getattr(sys, 'frozen', False):
    BASE_DIR = sys._MEIPASS
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

CONFIG_PATH = os.path.join(os.path.dirname(sys.executable if getattr(sys, 'frozen', False)
                                            else os.path.abspath(__file__)), "config.json")

# ─────────────────────────────────────────────
# 로깅 설정
# ─────────────────────────────────────────────
def setup_logging(enabled: bool):
    level = logging.DEBUG if enabled else logging.WARNING
    fmt = "%(asctime)s [%(name)s] %(levelname)s: %(message)s"
    logging.basicConfig(level=level, format=fmt,
                        handlers=[
                            logging.StreamHandler(sys.stdout),
                            logging.FileHandler("motion_controller.log", encoding="utf-8"),
                        ])

# ─────────────────────────────────────────────
# 설정 로드
# ─────────────────────────────────────────────
def load_config() -> dict:
    default = {
        "camera_index": 0,
        "display_width": 640,
        "display_height": 480,
        "target_fps": 30,
        "show_skeleton": True,
        "show_fps": True,
        "show_landmarks": True,
        "log_enabled": True,
        "sensitivity": {
            "run_knee_velocity_threshold": 0.018,
            "run_min_duration": 0.25,
            "run_stop_timeout": 0.35,
            "strafe_hip_velocity_threshold": 0.012,
            "strafe_min_duration": 0.2,
            "strafe_stop_timeout": 0.3,
            "jump_velocity_threshold": 0.022,
            "jump_cooldown": 0.6,
            "jump_min_rise": 0.015,
            "punch_wrist_velocity_threshold": 0.045,
            "punch_acceleration_threshold": 0.06,
            "punch_cooldown": 0.35,
            "punch_extension_threshold": 0.18,
            "noise_filter_alpha": 0.4,
            "history_frames": 12,
        },
        "glow": {"enabled": True, "radius": 8, "intensity": 0.7},
    }

    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                user_cfg = json.load(f)
            # 재귀 병합
            def merge(base, override):
                for k, v in override.items():
                    if k in base and isinstance(base[k], dict) and isinstance(v, dict):
                        merge(base[k], v)
                    else:
                        base[k] = v
            merge(default, user_cfg)
        except Exception as e:
            print(f"[Config] Failed to load config.json: {e}, using defaults")
    else:
        # 기본 config.json 생성
        try:
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump(default, f, indent=2, ensure_ascii=False)
            print(f"[Config] Created default config.json at {CONFIG_PATH}")
        except Exception:
            pass

    return default


# ─────────────────────────────────────────────
# FPS 계산기
# ─────────────────────────────────────────────
class FPSCounter:
    def __init__(self, window: int = 30):
        self._times: deque = deque(maxlen=window)

    def tick(self):
        self._times.append(time.perf_counter())

    @property
    def fps(self) -> float:
        if len(self._times) < 2:
            return 0.0
        span = self._times[-1] - self._times[0]
        return (len(self._times) - 1) / span if span > 0 else 0.0


# ─────────────────────────────────────────────
# 메인 애플리케이션
# ─────────────────────────────────────────────
class MotionControllerApp:
    WINDOW_NAME = "MotionController"

    def __init__(self, config: dict):
        self.cfg = config
        self.logger = logging.getLogger("App")

        # 모듈 임포트 (여기서 해야 PyInstaller 경로 문제 방지)
        from pose_tracker import PoseTracker
        from gesture_engine import GestureEngine, Action
        from input_handler import InputHandler
        from renderer import Renderer
        from camera_selector import find_available_cameras, select_camera_cv

        self.Action = Action

        # 카메라 선택
        cam_idx = config["camera_index"]
        available = find_available_cameras()
        self.logger.info(f"Available cameras: {available}")

        if not available:
            self.logger.error("No cameras found!")
            print("\n[ERROR] 카메라를 찾을 수 없습니다. USB 카메라를 연결하세요.")
            sys.exit(1)

        if len(available) > 1:
            cam_idx = select_camera_cv(available, cam_idx)

        self.logger.info(f"Using camera {cam_idx}")

        # 카메라 초기화
        self.cap = cv2.VideoCapture(cam_idx, cv2.CAP_DSHOW)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, config["display_width"])
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config["display_height"])
        self.cap.set(cv2.CAP_PROP_FPS, config["target_fps"])
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)

        if not self.cap.isOpened():
            self.logger.error(f"Failed to open camera {cam_idx}")
            sys.exit(1)

        # 모듈 초기화
        self.tracker = PoseTracker(config)
        self.gesture = GestureEngine(config)
        self.input_handler = InputHandler()
        self.renderer = Renderer(config)
        self.fps_counter = FPSCounter(30)

        self._running = False
        self._input_enabled = True
        self._current_actions: Set = {Action.NONE}

        # 스레드 동기화
        self._frame_lock = threading.Lock()
        self._latest_frame = None
        self._latest_actions: Set = {Action.NONE}

        self.logger.info("MotionControllerApp initialized")

    def run(self):
        self._running = True
        self.logger.info("Starting main loop")

        # 창 설정
        cv2.namedWindow(self.WINDOW_NAME, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(self.WINDOW_NAME, self.cfg["display_width"], self.cfg["display_height"])

        target_interval = 1.0 / self.cfg.get("target_fps", 30)

        print("\n" + "="*50)
        print("  MotionController 실행 중")
        print("="*50)
        print("  [Q / ESC] 종료")
        print("  [Space]   입력 활성/비활성 토글")
        print("  [S]       스켈레톤 표시 토글")
        print("="*50 + "\n")

        frame_start = time.perf_counter()

        while self._running:
            loop_start = time.perf_counter()

            ret, frame = self.cap.read()
            if not ret:
                self.logger.warning("Frame read failed, retrying...")
                time.sleep(0.01)
                continue

            # 좌우 반전 (거울 모드)
            frame = cv2.flip(frame, 1)

            # BGR → RGB for MediaPipe
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            # 포즈 추적
            pose_ok = self.tracker.update(frame_rgb)

            # 동작 인식
            if pose_ok:
                actions = self.gesture.update(self.tracker)
            else:
                actions = {self.Action.NONE}
                # 포즈 없으면 모든 키 해제
                self.input_handler.process({self.Action.NONE})

            # 입력 처리
            if self._input_enabled and pose_ok:
                self.input_handler.process(actions)

            # FPS 업데이트
            self.fps_counter.tick()
            fps = self.fps_counter.fps

            # 렌더링
            display = self.renderer.draw(frame, self.tracker, actions, fps)

            # 입력 비활성 표시
            if not self._input_enabled:
                h, w = display.shape[:2]
                overlay = display.copy()
                cv2.rectangle(overlay, (0, 0), (w, 30), (0, 0, 150), -1)
                cv2.addWeighted(overlay, 0.6, display, 0.4, 0, display)
                cv2.putText(display, "INPUT DISABLED (Space to enable)",
                            (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                            (255, 255, 255), 1, cv2.LINE_AA)

            cv2.imshow(self.WINDOW_NAME, display)

            # 키 입력 처리
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q') or key == 27:  # Q or ESC
                self.logger.info("Quit requested")
                break
            elif key == ord(' '):
                self._input_enabled = not self._input_enabled
                self.input_handler.set_enabled(self._input_enabled)
                status = "ENABLED" if self._input_enabled else "DISABLED"
                print(f"[Input] {status}")
            elif key == ord('s'):
                self.renderer.show_skeleton = not self.renderer.show_skeleton
                print(f"[Skeleton] {'ON' if self.renderer.show_skeleton else 'OFF'}")

            # FPS 제한
            elapsed = time.perf_counter() - loop_start
            sleep_time = target_interval - elapsed
            if sleep_time > 0:
                time.sleep(sleep_time)

        self._cleanup()

    def _cleanup(self):
        self.logger.info("Cleaning up...")
        self._running = False
        self.input_handler.close()
        self.tracker.close()
        if self.cap.isOpened():
            self.cap.release()
        cv2.destroyAllWindows()
        self.logger.info("Cleanup complete")


# ─────────────────────────────────────────────
# 엔트리포인트
# ─────────────────────────────────────────────
def main():
    config = load_config()
    setup_logging(config.get("log_enabled", True))
    logger = logging.getLogger("Main")
    logger.info("MotionController starting")

    try:
        app = MotionControllerApp(config)
        app.run()
    except KeyboardInterrupt:
        logger.info("Interrupted by user")
    except Exception as e:
        logger.exception(f"Fatal error: {e}")
        print(f"\n[ERROR] {e}")
        input("\nPress Enter to exit...")
    finally:
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
