========================================
 MotionController - 웹캠 모션 컨트롤러
========================================

[ 실행 방법 ]

방법 1: Python으로 직접 실행
  1. pip install -r requirements.txt
  2. python main.py

방법 2: EXE 빌드 후 실행
  1. build.bat 더블클릭
  2. dist\MotionController\MotionController.exe 실행
     (폴더 전체를 유지해야 함)

[ 조작법 ]
  Q / ESC   : 프로그램 종료
  Space     : 키보드/마우스 입력 활성/비활성 토글
  S         : 스켈레톤 표시 켜기/끄기

[ 동작 인식 ]
  달리기(앞): 제자리에서 달리는 모션 → W 키
  뒤로가기 : 뒤로 물러나는 모션     → S 키
  왼쪽이동 : 화면 오른쪽으로 이동   → A 키
  오른쪽이동: 화면 왼쪽으로 이동    → D 키
  점프     : 위로 점프 모션         → Space 키
  펀치     : 주먹 앞으로 빠르게 뻗기→ 마우스 좌클릭

[ 감도 조정 ]
  config.json 파일을 텍스트 에디터로 열어서
  sensitivity 값을 조정하세요.
  (높을수록 민감도 낮아짐)

[ 예상 문제 및 해결 ]

Q: 카메라가 인식 안 됨
A: config.json에서 camera_index를 0, 1, 2로 바꿔보세요.

Q: 동작이 잘 안 잡힘
A: sensitivity 값을 낮추세요. (0.01 ~ 0.02 범위)
   전신이 카메라에 잘 보이도록 거리를 조절하세요.

Q: 오작동이 너무 많음
A: sensitivity 값을 높이세요.
   조명을 밝게 하면 인식률이 올라갑니다.

Q: EXE 실행 시 antivirus 경고
A: PyInstaller 빌드 특성상 발생할 수 있습니다.
   예외 처리하거나 python main.py로 실행하세요.

Q: FPS가 낮음
A: config.json에서 model_complexity를 0으로 낮추세요.
   (pose_tracker.py의 model_complexity=1 → 0)
========================================
