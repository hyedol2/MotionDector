"""
input_handler.py
pynput 기반 키보드/마우스 입력 처리
"""
import logging
import threading
from typing import Set, Optional
from pynput.keyboard import Controller as KeyboardController, Key
from pynput.mouse import Controller as MouseController, Button

from gesture_engine import Action

logger = logging.getLogger("InputHandler")


class InputHandler:
    """
    Action 집합을 받아 실제 입력으로 변환
    - 지속형 동작: 키 홀드/해제
    - 단발형 동작: 클릭/키 탭
    """

    ACTION_KEY_MAP = {
        Action.RUN: 'w',
        Action.BACK: 's',
        Action.LEFT: 'a',
        Action.RIGHT: 'd',
    }

    def __init__(self):
        self.keyboard = KeyboardController()
        self.mouse = MouseController()
        self._held_keys: Set = set()
        self._lock = threading.Lock()
        self._enabled = True

    def process(self, actions: Set[Action]):
        if not self._enabled:
            self._release_all()
            return

        with self._lock:
            # 지속형 키 처리
            desired_keys = set()
            for action, key in self.ACTION_KEY_MAP.items():
                if action in actions:
                    desired_keys.add(key)

            # 해제해야 할 키
            to_release = self._held_keys - desired_keys
            for key in to_release:
                try:
                    self.keyboard.release(key)
                    logger.debug(f"Released: {key}")
                except Exception as e:
                    logger.warning(f"Release error: {e}")

            # 눌러야 할 키
            to_press = desired_keys - self._held_keys
            for key in to_press:
                try:
                    self.keyboard.press(key)
                    logger.debug(f"Pressed: {key}")
                except Exception as e:
                    logger.warning(f"Press error: {e}")

            self._held_keys = desired_keys.copy()

            # 단발형 처리
            if Action.JUMP in actions:
                try:
                    self.keyboard.tap(Key.space)
                    logger.debug("JUMP: space tapped")
                except Exception as e:
                    logger.warning(f"Jump error: {e}")

            if Action.PUNCH in actions:
                try:
                    self.mouse.click(Button.left, 1)
                    logger.debug("PUNCH: left click")
                except Exception as e:
                    logger.warning(f"Punch click error: {e}")

    def _release_all(self):
        with self._lock:
            for key in list(self._held_keys):
                try:
                    self.keyboard.release(key)
                except Exception:
                    pass
            self._held_keys.clear()

    def set_enabled(self, enabled: bool):
        self._enabled = enabled
        if not enabled:
            self._release_all()
            logger.info("Input disabled - all keys released")

    def close(self):
        self._release_all()
        logger.info("InputHandler closed")
