"""
renderer.py
OpenCV 기반 화면 렌더링 - 스켈레톤 글로우 + 동작 오버레이 + FPS
"""
import cv2
import numpy as np
from typing import Set, Optional, Tuple
import mediapipe as mp

from gesture_engine import Action
from pose_tracker import PoseTracker


# 동작별 오버레이 색상 (BGR)
ACTION_COLORS = {
    Action.NONE:  (80, 80, 80),
    Action.RUN:   (0, 200, 80),
    Action.BACK:  (200, 100, 0),
    Action.LEFT:  (200, 160, 0),
    Action.RIGHT: (0, 160, 200),
    Action.JUMP:  (0, 80, 255),
    Action.PUNCH: (0, 0, 230),
}

ACTION_LABELS = {
    Action.NONE:  "NONE",
    Action.RUN:   "RUN",
    Action.BACK:  "BACK",
    Action.LEFT:  "LEFT",
    Action.RIGHT: "RIGHT",
    Action.JUMP:  "JUMP",
    Action.PUNCH: "PUNCH",
}


class Renderer:
    def __init__(self, config: dict):
        self.cfg = config
        self.glow_cfg = config.get("glow", {"enabled": True, "radius": 8, "intensity": 0.7})
        self.show_skeleton = config.get("show_skeleton", True)
        self.show_fps = config.get("show_fps", True)
        self.show_landmarks = config.get("show_landmarks", True)

        self._fps_history = []
        self._last_frame_time = None

        # 글로우 레이어 캐시
        self._glow_layer = None

    def draw(self,
             frame: np.ndarray,
             tracker: PoseTracker,
             actions: Set[Action],
             fps: float) -> np.ndarray:
        """모든 시각 요소를 프레임에 그려서 반환"""
        out = frame.copy()

        if self.show_skeleton and tracker.raw_landmarks is not None:
            out = self._draw_skeleton_with_glow(out, tracker)

        self._draw_action_overlay(out, actions)

        if self.show_fps:
            self._draw_fps(out, fps)

        return out

    # ─────────────────────────────────────────────
    # 스켈레톤 + 글로우
    # ─────────────────────────────────────────────
    def _draw_skeleton_with_glow(self, frame: np.ndarray, tracker: PoseTracker) -> np.ndarray:
        h, w = frame.shape[:2]
        lm = tracker.raw_landmarks.landmark

        def to_px(idx) -> Optional[Tuple[int, int]]:
            p = lm[idx]
            if p.visibility < 0.4:
                return None
            return (int(p.x * w), int(p.y * h))

        glow_enabled = self.glow_cfg.get("enabled", True)
        glow_r = int(self.glow_cfg.get("radius", 8))
        glow_intensity = float(self.glow_cfg.get("intensity", 0.7))

        if glow_enabled:
            glow_layer = np.zeros_like(frame, dtype=np.float32)

        result = frame.copy().astype(np.float32)

        # 뼈 연결선 그리기
        for (i, j), color in tracker.SKELETON_COLORS.items():
            p1 = to_px(i)
            p2 = to_px(j)
            if p1 is None or p2 is None:
                continue

            if glow_enabled:
                # 글로우 레이어에 두꺼운 선
                cv2.line(glow_layer, p1, p2, color, glow_r * 2)

            # 실제 선 (얇게)
            cv2.line(result.astype(np.uint8), p1, p2, color, 2)
            cv2.line(result, p1, p2, np.array(color, dtype=np.float32), 2)

        # 관절 점
        for name, idx in tracker.LANDMARKS.items():
            p = to_px(idx)
            if p is None:
                continue

            # 관절별 색깔
            joint_color = self._joint_color(name)

            if glow_enabled:
                cv2.circle(glow_layer, p, glow_r + 2, joint_color, -1)

            cv2.circle(result.astype(np.uint8), p, 4, joint_color, -1)
            cv2.circle(result, p, 4, np.array(joint_color, dtype=np.float32), -1)

        if glow_enabled:
            # 블러로 글로우 효과
            blur_size = max(glow_r * 2 + 1, 5)
            if blur_size % 2 == 0:
                blur_size += 1
            blurred_glow = cv2.GaussianBlur(glow_layer, (blur_size, blur_size), 0)
            result = np.clip(result + blurred_glow * glow_intensity, 0, 255)

        return result.astype(np.uint8)

    def _joint_color(self, name: str) -> Tuple[int, int, int]:
        color_map = {
            "nose": (255, 255, 255),
            "left_shoulder": (0, 200, 255), "right_shoulder": (255, 200, 0),
            "left_elbow": (0, 150, 255),    "right_elbow": (255, 150, 0),
            "left_wrist": (0, 80, 255),     "right_wrist": (255, 80, 0),
            "left_hip": (0, 255, 150),      "right_hip": (150, 255, 0),
            "left_knee": (0, 255, 80),      "right_knee": (80, 255, 0),
            "left_ankle": (0, 200, 50),     "right_ankle": (50, 200, 0),
        }
        return color_map.get(name, (200, 200, 200))

    # ─────────────────────────────────────────────
    # 동작 오버레이
    # ─────────────────────────────────────────────
    def _draw_action_overlay(self, frame: np.ndarray, actions: Set[Action]):
        display_actions = actions - {Action.NONE} if len(actions) > 1 else actions
        if not display_actions:
            display_actions = {Action.NONE}

        y = 12
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.75
        thickness = 2
        padding = 6

        for action in sorted(display_actions, key=lambda a: a.value):
            label = ACTION_LABELS.get(action, str(action))
            color = ACTION_COLORS.get(action, (80, 80, 80))

            (tw, th), baseline = cv2.getTextSize(label, font, font_scale, thickness)
            box_x1 = 8
            box_y1 = y
            box_x2 = box_x1 + tw + padding * 2
            box_y2 = y + th + padding * 2

            # 반투명 배경
            overlay = frame.copy()
            cv2.rectangle(overlay, (box_x1, box_y1), (box_x2, box_y2), color, -1)
            cv2.addWeighted(overlay, 0.75, frame, 0.25, 0, frame)

            # 테두리
            cv2.rectangle(frame, (box_x1, box_y1), (box_x2, box_y2), color, 1)

            # 텍스트
            cv2.putText(frame, label,
                        (box_x1 + padding, box_y2 - padding - baseline // 2),
                        font, font_scale, (255, 255, 255), thickness, cv2.LINE_AA)

            y = box_y2 + 4

    # ─────────────────────────────────────────────
    # FPS 표시
    # ─────────────────────────────────────────────
    def _draw_fps(self, frame: np.ndarray, fps: float):
        h, w = frame.shape[:2]
        label = f"FPS: {fps:.1f}"
        font = cv2.FONT_HERSHEY_SIMPLEX
        (tw, th), _ = cv2.getTextSize(label, font, 0.55, 1)
        x = w - tw - 10
        y = th + 8

        cv2.putText(frame, label, (x, y), font, 0.55, (0, 0, 0), 3, cv2.LINE_AA)
        cv2.putText(frame, label, (x, y), font, 0.55, (180, 255, 180), 1, cv2.LINE_AA)
