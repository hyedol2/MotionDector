"""
camera_selector.py
사용 가능한 카메라 목록 탐색 + 선택 UI
"""
import cv2
import logging
from typing import List, Tuple

logger = logging.getLogger("CameraSelector")


def find_available_cameras(max_check: int = 5) -> List[int]:
    """사용 가능한 카메라 인덱스 목록 반환"""
    available = []
    for i in range(max_check):
        cap = cv2.VideoCapture(i, cv2.CAP_DSHOW)
        if cap.isOpened():
            ret, _ = cap.read()
            if ret:
                available.append(i)
                logger.info(f"Camera {i} found")
        cap.release()
    return available


def select_camera_cv(cameras: List[int], default: int = 0) -> int:
    """
    OpenCV 창으로 카메라 선택 UI 표시
    카메라가 1개면 바로 반환
    """
    if len(cameras) == 0:
        logger.error("No cameras found!")
        return 0

    if len(cameras) == 1:
        return cameras[0]

    # 선택 화면 생성
    h, w = 300, 480
    panel = np.zeros((h, w, 3), dtype=np.uint8)

    font = cv2.FONT_HERSHEY_SIMPLEX
    selected = 0

    while True:
        panel[:] = (20, 20, 30)
        cv2.putText(panel, "Select Camera", (20, 40), font, 0.9, (200, 200, 255), 2, cv2.LINE_AA)
        cv2.putText(panel, "Press number key or Enter", (20, 65), font, 0.45, (150, 150, 150), 1, cv2.LINE_AA)

        for i, cam_idx in enumerate(cameras):
            y = 100 + i * 45
            is_sel = i == selected
            color = (50, 200, 100) if is_sel else (100, 100, 100)
            prefix = ">> " if is_sel else "   "
            cv2.rectangle(panel, (15, y - 20), (w - 15, y + 15), color, -1 if is_sel else 1)
            cv2.putText(panel, f"{prefix}Camera {cam_idx}", (25, y + 2),
                        font, 0.65, (255, 255, 255) if is_sel else (180, 180, 180), 1, cv2.LINE_AA)

        cv2.imshow("MotionController - Camera Select", panel)
        key = cv2.waitKey(30) & 0xFF

        if key == 13 or key == 32:  # Enter or Space
            cv2.destroyWindow("MotionController - Camera Select")
            return cameras[selected]
        elif key == ord('q') or key == 27:
            cv2.destroyWindow("MotionController - Camera Select")
            return cameras[0]
        elif ord('0') <= key <= ord('9'):
            num = key - ord('0')
            if num < len(cameras):
                cv2.destroyWindow("MotionController - Camera Select")
                return cameras[num]
        elif key == 82 or key == ord('w'):  # 위
            selected = (selected - 1) % len(cameras)
        elif key == 84 or key == ord('s'):  # 아래
            selected = (selected + 1) % len(cameras)


import numpy as np  # 맨 아래 임포트 (순환 방지)
