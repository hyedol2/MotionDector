"""
pose_tracker.py
MediaPipe Pose 래퍼 + 관절 속도/가속도/히스토리 관리
"""
import time
import numpy as np
import mediapipe as mp
from collections import deque
from typing import Optional, List, Dict, Tuple


class JointState:
    """단일 관절의 위치/속도/가속도를 관리하는 클래스"""

    def __init__(self, history_size: int = 12, alpha: float = 0.4):
        self.history_size = history_size
        self.alpha = alpha  # 로우패스 필터 계수
        self.positions: deque = deque(maxlen=history_size)
        self.timestamps: deque = deque(maxlen=history_size)
        self.velocities: deque = deque(maxlen=history_size)
        self.accelerations: deque = deque(maxlen=history_size)
        self._filtered_pos: Optional[np.ndarray] = None

    def update(self, pos: np.ndarray, t: float):
        """새 위치 추가 + 속도/가속도 계산"""
        # 로우패스 필터 적용
        if self._filtered_pos is None:
            self._filtered_pos = pos.copy()
        else:
            self._filtered_pos = self.alpha * pos + (1 - self.alpha) * self._filtered_pos

        self.positions.append(self._filtered_pos.copy())
        self.timestamps.append(t)

        # 속도 계산
        if len(self.positions) >= 2:
            dt = self.timestamps[-1] - self.timestamps[-2]
            if dt > 0:
                vel = (self.positions[-1] - self.positions[-2]) / dt
                self.velocities.append(vel)
            else:
                self.velocities.append(np.zeros(3))
        else:
            self.velocities.append(np.zeros(3))

        # 가속도 계산
        if len(self.velocities) >= 2:
            dt = self.timestamps[-1] - self.timestamps[-2]
            if dt > 0:
                acc = (self.velocities[-1] - self.velocities[-2]) / dt
                self.accelerations.append(acc)
            else:
                self.accelerations.append(np.zeros(3))
        else:
            self.accelerations.append(np.zeros(3))

    @property
    def pos(self) -> Optional[np.ndarray]:
        return self.positions[-1] if self.positions else None

    @property
    def vel(self) -> Optional[np.ndarray]:
        return self.velocities[-1] if self.velocities else None

    @property
    def acc(self) -> Optional[np.ndarray]:
        return self.accelerations[-1] if self.accelerations else None

    def speed(self) -> float:
        """현재 속도의 크기 (XY 평면)"""
        if self.vel is None:
            return 0.0
        return float(np.linalg.norm(self.vel[:2]))

    def speed_y(self) -> float:
        """Y축 속도 (음수 = 위로 올라감, 좌표계 주의)"""
        if self.vel is None:
            return 0.0
        return float(self.vel[1])

    def speed_x(self) -> float:
        if self.vel is None:
            return 0.0
        return float(self.vel[0])

    def accel_magnitude(self) -> float:
        if self.acc is None:
            return 0.0
        return float(np.linalg.norm(self.acc[:2]))

    def recent_max_speed(self, n: int = 5) -> float:
        """최근 n 프레임 중 최대 속도"""
        if not self.velocities:
            return 0.0
        recent = list(self.velocities)[-n:]
        return max(float(np.linalg.norm(v[:2])) for v in recent)

    def recent_max_speed_y(self, n: int = 5) -> float:
        if not self.velocities:
            return 0.0
        recent = list(self.velocities)[-n:]
        return max(float(abs(v[1])) for v in recent)


class PoseTracker:
    """MediaPipe Pose 래퍼 - 관절 상태 일괄 관리"""

    # 사용할 랜드마크 인덱스
    LANDMARKS = {
        "nose": 0,
        "left_shoulder": 11, "right_shoulder": 12,
        "left_elbow": 13, "right_elbow": 14,
        "left_wrist": 15, "right_wrist": 16,
        "left_hip": 23, "right_hip": 24,
        "left_knee": 25, "right_knee": 26,
        "left_ankle": 27, "right_ankle": 28,
    }

    # 스켈레톤 연결 (랜드마크 인덱스 쌍)
    SKELETON_CONNECTIONS = [
        (11, 12),  # 양 어깨
        (11, 13), (13, 15),  # 왼팔
        (12, 14), (14, 16),  # 오른팔
        (11, 23), (12, 24),  # 몸통
        (23, 24),  # 골반
        (23, 25), (25, 27),  # 왼 다리
        (24, 26), (26, 28),  # 오른 다리
        (0, 11), (0, 12),   # 머리-어깨
    ]

    # 연결별 색상 (BGR) - 글로우용
    SKELETON_COLORS = {
        (11, 12): (0, 255, 255),
        (11, 13): (0, 200, 255), (13, 15): (0, 150, 255),
        (12, 14): (255, 200, 0), (14, 16): (255, 150, 0),
        (11, 23): (0, 255, 150), (12, 24): (0, 255, 150),
        (23, 24): (0, 255, 50),
        (23, 25): (150, 255, 0), (25, 27): (100, 255, 0),
        (24, 26): (255, 0, 200), (26, 28): (255, 0, 150),
        (0, 11): (200, 200, 255), (0, 12): (200, 200, 255),
    }

    def __init__(self, config: dict):
        self.cfg = config
        sens = config["sensitivity"]
        self.history_size = sens["history_frames"]
        self.alpha = sens["noise_filter_alpha"]

        mp_pose = mp.solutions.pose
        self.pose = mp_pose.Pose(
            static_image_mode=False,
            model_complexity=1,
            smooth_landmarks=True,
            enable_segmentation=False,
            smooth_segmentation=False,
            min_detection_confidence=0.6,
            min_tracking_confidence=0.5,
        )

        self.joints: Dict[str, JointState] = {
            name: JointState(self.history_size, self.alpha)
            for name in self.LANDMARKS
        }

        self.raw_landmarks = None  # 원본 랜드마크 (시각화용)
        self.last_update = time.time()
        self.frame_count = 0

    def update(self, frame_rgb: np.ndarray) -> bool:
        """프레임 처리 - True면 포즈 감지 성공"""
        t = time.time()
        results = self.pose.process(frame_rgb)

        if not results.pose_landmarks:
            self.raw_landmarks = None
            return False

        self.raw_landmarks = results.pose_landmarks
        lm = results.pose_landmarks.landmark

        for name, idx in self.LANDMARKS.items():
            p = lm[idx]
            pos = np.array([p.x, p.y, p.z], dtype=np.float32)
            self.joints[name].update(pos, t)

        self.last_update = t
        self.frame_count += 1
        return True

    def get_center(self) -> Optional[np.ndarray]:
        """신체 중심 (양 힙 중간)"""
        lh = self.joints["left_hip"].pos
        rh = self.joints["right_hip"].pos
        if lh is None or rh is None:
            return None
        return (lh + rh) / 2.0

    def get_center_velocity(self) -> Optional[np.ndarray]:
        lh = self.joints["left_hip"].vel
        rh = self.joints["right_hip"].vel
        if lh is None or rh is None:
            return None
        return (lh + rh) / 2.0

    def get_shoulder_center(self) -> Optional[np.ndarray]:
        ls = self.joints["left_shoulder"].pos
        rs = self.joints["right_shoulder"].pos
        if ls is None or rs is None:
            return None
        return (ls + rs) / 2.0

    def close(self):
        self.pose.close()
